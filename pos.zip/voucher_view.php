<?php
// voucher_view.php

// Access the global $connection variable
global $connection;

if (!is_logged_in()) {
    flash_message('error', 'Please log in to view vouchers.');
    redirect('index.php?page=login');
}

$voucher_id = $_GET['id'] ?? null;

if (!$voucher_id || !is_numeric($voucher_id)) {
    flash_message('error', 'Invalid voucher ID.');
    redirect('index.php?page=voucher_list');
}

$user_id = $_SESSION['user_id'];
$is_admin = is_admin();

$voucher = null;
$breakdowns = [];

try {
    // Fetch voucher details
    $query_voucher = "SELECT v.*, r.region_name, r.prefix, u.username AS created_by_username
                      FROM vouchers v
                      JOIN regions r ON v.region_id = r.id
                      JOIN users u ON v.created_by_user_id = u.id
                      WHERE v.id = ?";
    if (!$is_admin) {
        $query_voucher .= " AND v.created_by_user_id = ?"; // Restrict for non-admins
    }

    $stmt_voucher = mysqli_prepare($connection, $query_voucher);
    if ($stmt_voucher) {
        if (!$is_admin) {
            mysqli_stmt_bind_param($stmt_voucher, 'ii', $voucher_id, $user_id);
        } else {
            mysqli_stmt_bind_param($stmt_voucher, 'i', $voucher_id);
        }
        mysqli_stmt_execute($stmt_voucher);
        $result_voucher = mysqli_stmt_get_result($stmt_voucher);
        $voucher = mysqli_fetch_assoc($result_voucher);
        mysqli_free_result($result_voucher);
        mysqli_stmt_close($stmt_voucher);

        if (!$voucher) {
            flash_message('error', 'Voucher not found or you do not have permission to view it.');
            redirect('index.php?page=voucher_list');
        }

        // Fetch voucher breakdowns
        $stmt_breakdowns = mysqli_prepare($connection, "SELECT * FROM voucher_breakdowns WHERE voucher_id = ?");
        if ($stmt_breakdowns) {
            mysqli_stmt_bind_param($stmt_breakdowns, 'i', $voucher_id);
            mysqli_stmt_execute($stmt_breakdowns);
            $result_breakdowns = mysqli_stmt_get_result($stmt_breakdowns);
            while ($row = mysqli_fetch_assoc($result_breakdowns)) {
                $breakdowns[] = $row;
            }
            mysqli_free_result($result_breakdowns);
            mysqli_stmt_close($stmt_breakdowns);
        } else {
            flash_message('error', 'Error fetching voucher breakdowns: ' . mysqli_error($connection));
        }
    } else {
        flash_message('error', 'Error preparing voucher details query: ' . mysqli_error($connection));
        redirect('index.php?page=voucher_list');
    }
} catch (Exception $e) {
    flash_message('error', 'An unexpected error occurred: ' . $e->getMessage());
    redirect('index.php?page=voucher_list');
}

// Now include the header and render the form
include_template('header', ['page' => 'voucher_view']);
?>

<div class="bg-white p-8 rounded-lg shadow-xl w-full">
    <h2 class="text-3xl font-bold text-gray-800 mb-6 text-center">Voucher Details</h2>

    <?php if ($voucher): ?>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <!-- Voucher Main Details -->
            <div class="bg-gray-50 p-6 rounded-lg shadow-inner">
                <h3 class="text-xl font-semibold text-gray-700 mb-4 border-b pb-2">Voucher Information</h3>
                <p class="mb-2"><strong class="text-gray-800">Voucher Code:</strong> <span class="font-mono text-indigo-600 text-lg"><?php echo htmlspecialchars($voucher['voucher_code']); ?></span></p>
                <p class="mb-2"><strong class="text-gray-800">Origin Region:</strong> <?php echo htmlspecialchars($voucher['region_name']); ?> (<?php echo htmlspecialchars($voucher['prefix']); ?>)</p>
                <p class="mb-2"><strong class="text-gray-800">Weight (kg):</strong> <?php echo htmlspecialchars($voucher['weight_kg']); ?></p>
                <p class="mb-2"><strong class="text-gray-800">Price per Kg:</strong> <?php echo htmlspecialchars($voucher['price_per_kg_at_voucher']); ?></p>
                <p class="mb-2"><strong class="text-gray-800">Delivery Charge:</strong> <?php echo htmlspecialchars($voucher['delivery_charge']); ?></p>
                <p class="mb-2 text-xl font-bold"><strong class="text-gray-800">Total Amount:</strong> <span class="text-green-600"><?php echo htmlspecialchars($voucher['total_amount'] . ' ' . $voucher['currency']); ?></span></p>
                <p class="mb-2"><strong class="text-gray-800">Payment Method:</strong> <?php echo htmlspecialchars($voucher['payment_method'] ?: 'N/A'); ?></p>
                <p class="mb-2"><strong class="text-gray-800">Delivery Type:</strong> <?php echo htmlspecialchars($voucher['delivery_type'] ?: 'N/A'); ?></p>
                <p class="mb-2"><strong class="text-gray-800">Notes:</strong> <?php echo htmlspecialchars($voucher['notes'] ?: 'N/A'); ?></p>
                <p class="mb-2"><strong class="text-gray-800">Created By:</strong> <?php echo htmlspecialchars($voucher['created_by_username']); ?></p>
                <p class="mb-2"><strong class="text-gray-800">Created At:</strong> <?php echo date('Y-m-d H:i:s', strtotime($voucher['created_at'])); ?></p>
            </div>

            <!-- Sender & Receiver Details -->
            <div class="grid grid-cols-1 gap-6">
                <div class="bg-gray-50 p-6 rounded-lg shadow-inner">
                    <h3 class="text-xl font-semibold text-gray-700 mb-4 border-b pb-2">Sender Information</h3>
                    <p class="mb-2"><strong class="text-gray-800">Name:</strong> <?php echo htmlspecialchars($voucher['sender_name']); ?></p>
                    <p class="mb-2"><strong class="text-gray-800">Phone:</strong> <?php echo htmlspecialchars($voucher['sender_phone']); ?></p>
                    <p class="mb-2"><strong class="text-gray-800">Address:</strong> <?php echo htmlspecialchars($voucher['sender_address'] ?: 'N/A'); ?></p>
                    <p class="mb-2"><strong class="text-gray-800">Use sender address for checkout:</strong> <?php echo $voucher['use_sender_address_for_checkout'] ? 'Yes' : 'No'; ?></p>
                </div>
                <div class="bg-gray-50 p-6 rounded-lg shadow-inner">
                    <h3 class="text-xl font-semibold text-gray-700 mb-4 border-b pb-2">Receiver Information</h3>
                    <p class="mb-2"><strong class="text-gray-800">Name:</strong> <?php echo htmlspecialchars($voucher['receiver_name']); ?></p>
                    <p class="mb-2"><strong class="text-gray-800">Phone:</strong> <?php echo htmlspecialchars($voucher['receiver_phone']); ?></p>
                    <p class="mb-2"><strong class="text-gray-800">Address:</strong> <?php echo htmlspecialchars($voucher['receiver_address']); ?></p>
                </div>
            </div>
        </div>

        <!-- Voucher Breakdown Details -->
        <div class="mt-8 bg-gray-50 p-6 rounded-lg shadow-inner">
            <h3 class="text-xl font-semibold text-gray-700 mb-4 border-b pb-2">Item Breakdown</h3>
            <?php if (empty($breakdowns)): ?>
                <p class="text-gray-600">No specific item breakdowns found for this voucher.</p>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Item Type</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kg</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price per Kg</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Item Details (JSON)</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($breakdowns as $item): ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($item['item_type'] ?: 'N/A'); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo htmlspecialchars($item['kg'] ?: 'N/A'); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo htmlspecialchars($item['price_per_kg'] ?: 'N/A'); ?></td>
                                    <td class="px-6 py-4 text-sm text-gray-700">
                                        <?php
                                        // Attempt to pretty-print JSON
                                        if ($item['item_breakdown_json']) {
                                            $decoded_json = json_decode($item['item_breakdown_json'], true);
                                            if (json_last_error() === JSON_ERROR_NONE) {
                                                echo '<pre class="whitespace-pre-wrap break-all text-xs bg-gray-100 p-2 rounded">' . htmlspecialchars(json_encode($decoded_json, JSON_PRETTY_PRINT)) . '</pre>';
                                            } else {
                                                echo htmlspecialchars($item['item_breakdown_json']) . ' (Invalid JSON)';
                                            }
                                        } else {
                                            echo 'N/A';
                                        }
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <div class="flex justify-center mt-8 space-x-4">
            <a href="index.php?page=voucher_print&id=<?php echo htmlspecialchars($voucher['id']); ?>" target="_blank" class="btn bg-blue-600 hover:bg-blue-700 px-6 py-2">Print Voucher</a>
            <a href="index.php?page=voucher_list" class="btn btn-blue px-6 py-2">Back to Voucher List</a>
        </div>
    <?php endif; ?>
</div>

<?php include_template('footer'); ?>