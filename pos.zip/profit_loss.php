<?php
// profit_loss.php
// Admin-only page for calculating profits and expenses

include_template('header', ['page' => 'profit_loss']);

if (!is_logged_in() || !is_admin()) {
    flash_message('error', 'Access denied. You must be an ADMIN to view financial reports.');
    redirect('index.php?page=dashboard');
}

// Access the global $connection variable
global $connection;

$total_voucher_income = 0;
$total_other_income = 0; // New variable
$total_expenses = 0;
$net_worth = 0;

// Calculate total profit from vouchers (total_amount of all vouchers)
$result_voucher_income = mysqli_query($connection, "SELECT SUM(total_amount) AS total_voucher_income FROM vouchers");
if ($result_voucher_income) {
    $row_voucher_income = mysqli_fetch_assoc($result_voucher_income);
    $total_voucher_income = $row_voucher_income['total_voucher_income'] ?: 0;
    mysqli_free_result($result_voucher_income);
} else {
    flash_message('error', 'Error calculating total voucher income: ' . mysqli_error($connection));
}

// Calculate total other income (NEW)
$result_other_income = mysqli_query($connection, "SELECT SUM(amount) AS total_other_income FROM other_income");
if ($result_other_income) {
    $row_other_income = mysqli_fetch_assoc($result_other_income);
    $total_other_income = $row_other_income['total_other_income'] ?: 0;
    mysqli_free_result($result_other_income);
} else {
    flash_message('error', 'Error calculating total other income: ' . mysqli_error($connection));
}

// Calculate total expenses
$result_expenses = mysqli_query($connection, "SELECT SUM(amount) AS total_expenses FROM expenses");
if ($result_expenses) {
    $row_expenses = mysqli_fetch_assoc($result_expenses);
    $total_expenses = $row_expenses['total_expenses'] ?: 0;
    mysqli_free_result($result_expenses);
} else {
    flash_message('error', 'Error calculating total expenses: ' . mysqli_error($connection));
}

// Total Revenue = Voucher Income + Other Income
$total_revenue = $total_voucher_income + $total_other_income;

// Calculate net worth
$net_worth = $total_revenue - $total_expenses;

?>

<div class="bg-white p-8 rounded-lg shadow-xl w-full">
    <h2 class="text-3xl font-bold text-gray-800 mb-6 text-center">Profit & Loss Statement</h2>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8 text-center">
        <div class="bg-burgundy-light p-6 rounded-lg shadow-md transition-shadow duration-300 hover:shadow-lg">
            <p class="text-lg text-burgundy-dark font-semibold">Total Revenue</p>
            <p class="text-4xl font-bold text-burgundy mt-2">$<?php echo number_format($total_revenue, 2); ?></p>
            <p class="text-sm text-gray-600 mt-1">(Vouchers: $<?php echo number_format($total_voucher_income, 2); ?>, Other: $<?php echo number_format($total_other_income, 2); ?>)</p>
        </div>
        <div class="bg-red-50 p-6 rounded-lg shadow-md transition-shadow duration-300 hover:shadow-lg">
            <p class="text-lg text-red-700 font-semibold">Total Expenses</p>
            <p class="text-4xl font-bold text-red-600 mt-2">$<?php echo number_format($total_expenses, 2); ?></p>
        </div>
        <div class="p-6 rounded-lg shadow-md transition-shadow duration-300 hover:shadow-lg <?php echo ($net_worth >= 0) ? 'bg-green-50' : 'bg-red-50'; ?>">
            <p class="text-lg <?php echo ($net_worth >= 0) ? 'text-green-700' : 'text-red-700'; ?> font-semibold">Net Worth (Revenue - Expense)</p>
            <p class="text-4xl font-bold <?php echo ($net_worth >= 0) ? 'text-green-600' : 'text-red-600'; ?> mt-2">$<?php echo number_format($net_worth, 2); ?></p>
        </div>
    </div>

    <div class="mt-8 text-center">
        <a href="index.php?page=other_income" class="btn bg-green-600 hover:bg-green-700 px-6 py-2">Manage Other Income</a>
        <a href="index.php?page=expenses" class="btn btn-blue px-6 py-2 ml-4">Manage Expenses</a>
        <a href="index.php?page=admin_dashboard" class="btn bg-steel hover:bg-steel-dark px-6 py-2 ml-4">Back to Admin Dashboard</a>
    </div>
</div>

<?php include_template('footer'); ?>