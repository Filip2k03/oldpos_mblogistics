   <?php
// templates/header.php
// Common header for all pages, including Tailwind CSS CDN

// The $page variable is passed to include_template function
// No redirect logic here. Redirects MUST happen before any HTML output.

// Ensure assets.php is included to load CSS/JS
require_once __DIR__ . '/../assets.php';
?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - <?php echo ucfirst(str_replace('_', ' ', $page)); ?></title>
    <?php load_assets($page); // Load assets based on the current page ?>
    <style>
        
        /* Ship Loader Styles */
        .ship-loader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.7s ease-out, visibility 0.7s ease-out; /* Slower transition */
        }
        .mb-logo {
            font-size: 24px;
            font-weight: bold;
            color: var(--color-burgundy); /* Use Burgundy for logo */
            margin-top: 15px;
        }
        .progress-bar {
            width: 200px;
            height: 4px;
            background: #ecf0f1;
            border-radius: 2px;
            margin-top: 20px;
            overflow: hidden;
        }
        .progress {
            height: 100%;
            background: var(--color-burgundy); /* Use Burgundy for progress bar */
            width: 0%;
            transition: width 0.4s ease-out; /* Smooth progress transition */
        }
        .ship-loader.hidden {
            opacity: 0;
            visibility: hidden;
            pointer-events: none; /* Disable interaction when hidden */
        }
        /* Optional: animate the ship */
        .ship-svg {
            animation: float 3s ease-in-out infinite;
        }
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
    </style>
    </head>
    <body class="min-h-screen flex flex-col">
    <!-- 集装箱船加载器 -->
    <div class="ship-loader" id="shipLoader">
        <svg class="ship-svg" width="200" height="100" viewBox="0 0 200 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            <!-- Ship hull -->
            <rect x="20" y="70" width="160" height="20" rx="5" fill="#2c3e50" />
            <!-- Containers -->
            <rect x="35" y="50" width="30" height="20" rx="3" fill="#3498db" stroke="#2980b9" stroke-width="2"/>
            <rect x="70" y="50" width="30" height="20" rx="3" fill="#e74c3c" stroke="#c0392b" stroke-width="2"/>
            <rect x="105" y="50" width="30" height="20" rx="3" fill="#2ecc71" stroke="#27ae60" stroke-width="2"/>
            <rect x="140" y="50" width="30" height="20" rx="3" fill="#f1c40f" stroke="#f39c12" stroke-width="2"/>
            <!-- Ship bridge -->
            <rect x="110" y="35" width="20" height="15" rx="2" fill="#bdc3c7" />
            <!-- Water waves (optional) -->
            <ellipse cx="100" cy="92" rx="80" ry="6" fill="#b3e0fc" opacity="0.5"/>
        </svg>
        <div class="mb-logo">MB SHIPPING</div>
        <div class="progress-bar">
            <div class="progress" id="loaderProgress"></div>
        </div>
    </div>

    <nav class="bg-gray-800 shadow-lg">
        <div class="container mx-auto px-4 py-3 flex justify-between items-center">
            <div class="flex items-center">
                <a href="index.php?page=dashboard" class="text-white text-xl font-bold rounded-md px-3 py-2 hover:bg-gray-700"><?php echo APP_NAME; ?></a>
            </div>
            <div class="hidden md:flex items-center space-x-4">
                <?php if (is_logged_in()): ?>
                    <a href="index.php?page=dashboard" class="nav-link <?php echo ($page == 'dashboard' || $page == 'home') ? 'active' : ''; ?>">Dashboard</a>
                    <a href="index.php?page=voucher_create" class="nav-link <?php echo ($page == 'voucher_create') ? 'active' : ''; ?>">Create Voucher</a>
                    <a href="index.php?page=voucher_list" class="nav-link <?php echo ($page == 'voucher_list') ? 'active' : ''; ?>">Voucher List</a>
                    <a href="index.php?page=stock_list" class="nav-link <?php echo ($page == 'stock_list') ? 'active' : ''; ?>">Stock List</a>
                    <?php if (is_admin()): ?>
                        <a href="index.php?page=profit_loss" class="nav-link <?php echo ($page == 'profit_loss') ? 'active' : ''; ?>">Profit/Loss</a>
                        <a href="index.php?page=expenses" class="nav-link <?php echo ($page == 'expenses') ? 'active' : ''; ?>">Expenses</a>
                    <?php endif; ?>
                    <a href="index.php?page=logout" class="nav-link">Logout</a>
                <?php else: ?>
                    <a href="index.php?page=login" class="nav-link <?php echo ($page == 'login') ? 'active' : ''; ?>">Login</a>
                    <a href="index.php?page=register" class="nav-link <?php echo ($page == 'register') ? 'active' : ''; ?>">Register</a>
                <?php endif; ?>
            </div>
            <!-- Mobile Menu Button -->
            <div class="md:hidden">
                <button id="mobile-menu-button" class="text-gray-300 hover:text-white focus:outline-none focus:text-white">
                    <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                    </svg>
                </button>
            </div>
        </div>
        <!-- Mobile Menu -->
        <div id="mobile-menu" class="hidden md:hidden">
            <div class="px-2 pt-2 pb-3 space-y-1 sm:px-3">
                <?php if (is_logged_in()): ?>
                    <a href="index.php?page=dashboard" class="block nav-link <?php echo ($page == 'dashboard' || $page == 'home') ? 'active' : ''; ?>">Dashboard</a>
                    <a href="index.php?page=voucher_create" class="block nav-link <?php echo ($page == 'voucher_create') ? 'active' : ''; ?>">Create Voucher</a>
                    <a href="index.php?page=voucher_list" class="block nav-link <?php echo ($page == 'voucher_list') ? 'active' : ''; ?>">Voucher List</a>
                    <a href="index.php?page=stock_list" class="block nav-link <?php echo ($page == 'stock_list') ? 'active' : ''; ?>">Stock List</a>
                    <?php if (is_admin()): ?>
                        <a href="index.php?page=profit_loss" class="block nav-link <?php echo ($page == 'profit_loss') ? 'active' : ''; ?>">Profit/Loss</a>
                        <a href="index.php?page=expenses" class="block nav-link <?php echo ($page == 'expenses') ? 'active' : ''; ?>">Expenses</a>
                    <?php endif; ?>
                    <a href="index.php?page=logout" class="block nav-link">Logout</a>
                <?php else: ?>
                    <a href="index.php?page=login" class="block nav-link <?php echo ($page == 'login') ? 'active' : ''; ?>">Login</a>
                    <a href="index.php?page=register" class="block nav-link <?php echo ($page == 'register') ? 'active' : ''; ?>">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
<script src="../assets/js/main.js"></script>
    <script>
        // Show loading progress
        function updateLoaderProgress(percent) {
            document.getElementById('loaderProgress').style.width = percent + '%';
        }
        window.addEventListener('load', function() {
            updateLoaderProgress(100);
            setTimeout(function() {
                document.getElementById('shipLoader').classList.add('hidden');
            }, 500);
        });
        // Simulate loading progress
        let progress = 0;
        const interval = setInterval(function() {
            progress += Math.floor(Math.random() * 10);
            if (progress >= 90) clearInterval(interval);
            updateLoaderProgress(progress);
        }, 300);
    </script>
    </body>
    </html>