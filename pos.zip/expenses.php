<?php
// expenses.php
// Admin-only page for adding expenses

include_template('header', ['page' => 'expenses']);

if (!is_logged_in() || !is_admin()) {
    flash_message('error', 'Access denied. You must be an ADMIN to manage expenses.');
    redirect('index.php?page=dashboard');
}

$user_id = $_SESSION['user_id'];

// Access the global $connection variable
global $connection;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $description = trim($_POST['description'] ?? '');
    $amount = floatval($_POST['amount'] ?? 0);
    $expense_date = trim($_POST['expense_date'] ?? date('Y-m-d'));

    if (empty($description) || $amount <= 0 || empty($expense_date)) {
        flash_message('error', 'Please fill in all fields correctly (amount must be positive).');
        redirect('index.php?page=expenses');
    }

    $stmt = mysqli_prepare($connection, "INSERT INTO expenses (description, amount, expense_date, created_by_user_id) VALUES (?, ?, ?, ?)");
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'sdsi', $description, $amount, $expense_date, $user_id);
        if (mysqli_stmt_execute($stmt)) {
            flash_message('success', 'Expense added successfully!');
            redirect('index.php?page=expenses');
        } else {
            flash_message('error', 'Error adding expense: ' . mysqli_stmt_error($stmt));
        }
        mysqli_stmt_close($stmt);
    } else {
        flash_message('error', 'Database statement preparation error: ' . mysqli_error($connection));
    }
}

// Fetch existing expenses for display
$expenses = [];
$query = "SELECT e.*, u.username AS created_by_username
          FROM expenses e
          JOIN users u ON e.created_by_user_id = u.id
          ORDER BY e.expense_date DESC, e.created_at DESC";
$result = mysqli_query($connection, $query);
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $expenses[] = $row;
    }
    mysqli_free_result($result);
} else {
    flash_message('error', 'Error fetching expenses: ' . mysqli_error($connection));
}
?>

<div class="bg-white p-8 rounded-lg shadow-xl w-full">
    <h2 class="text-3xl font-bold text-gray-800 mb-6 text-center">Manage Expenses</h2>

    <div class="mb-8 p-6 bg-gray-50 rounded-lg shadow-inner">
        <h3 class="text-xl font-semibold text-gray-700 mb-4 border-b pb-2">Add New Expense</h3>
        <form action="index.php?page=expenses" method="POST">
            <div class="mb-4">
                <label for="description" class="block text-gray-700 text-sm font-semibold mb-2">Description:</label>
                <textarea id="description" name="description" rows="3" class="form-input" placeholder="e.g., Office rent, Utilities bill, Employee salary" required></textarea>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label for="amount" class="block text-gray-700 text-sm font-semibold mb-2">Amount:</label>
                    <input type="number" id="amount" name="amount" class="form-input" step="0.01" min="0.01" required>
                </div>
                <div>
                    <label for="expense_date" class="block text-gray-700 text-sm font-semibold mb-2">Date:</label>
                    <input type="date" id="expense_date" name="expense_date" class="form-input" value="<?php echo date('Y-m-d'); ?>" required>
                </div>
            </div>
            <div class="flex justify-end">
                <button type="submit" class="btn btn-green px-6 py-2">Add Expense</button>
            </div>
        </form>
    </div>

    <h3 class="text-xl font-semibold text-gray-700 mb-4 border-b pb-2">Recent Expenses</h3>
    <?php if (empty($expenses)): ?>
        <div class="text-center py-5">
            <p class="text-gray-600">No expenses recorded yet.</p>
        </div>
    <?php else: ?>
        <div class="overflow-x-auto rounded-lg shadow-md border border-gray-200">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-100">
                    <tr>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider rounded-tl-lg">Description</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Recorded By</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider rounded-tr-lg">Recorded At</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php foreach ($expenses as $expense): ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo htmlspecialchars($expense['description']); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700">$<?php echo htmlspecialchars(number_format($expense['amount'], 2)); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo htmlspecialchars($expense['expense_date']); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo htmlspecialchars($expense['created_by_username']); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo date('Y-m-d H:i', strtotime($expense['created_at'])); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php include_template('footer'); ?>