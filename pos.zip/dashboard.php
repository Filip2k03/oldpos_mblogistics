<?php
// dashboard.php
// Default dashboard for general users

include_template('header', ['page' => 'dashboard']);

if (!is_logged_in()) {
    flash_message('error', 'Please log in to view the dashboard.');
    redirect('index.php?page=login');
}

$username = $_SESSION['username'] ?? 'Guest';
$user_type = $_SESSION['user_type'] ?? 'General';
?>

<div class="bg-white p-8 rounded-lg shadow-xl text-center">
    <h2 class="text-4xl font-bold text-gray-800 mb-4">Welcome, <?php echo htmlspecialchars($username); ?>!</h2>
    <p class="text-xl text-gray-600 mb-8">Your User Type: <span class="font-semibold text-indigo-600"><?php echo htmlspecialchars($user_type); ?></span></p>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <a href="index.php?page=voucher_create" class="block p-6 bg-indigo-500 text-white rounded-lg shadow-md hover:bg-indigo-600 transition duration-300 transform hover:scale-105">
            <h3 class="text-2xl font-semibold mb-2">Create New Voucher</h3>
            <p>Start a new shipment entry.</p>
        </a>
        <a href="index.php?page=voucher_list" class="block p-6 bg-green-500 text-white rounded-lg shadow-md hover:bg-green-600 transition duration-300 transform hover:scale-105">
            <h3 class="text-2xl font-semibold mb-2">View Vouchers</h3>
            <p>Browse all existing vouchers.</p>
        </a>
        <a href="index.php?page=stock_list" class="block p-6 bg-yellow-500 text-white rounded-lg shadow-md hover:bg-yellow-600 transition duration-300 transform hover:scale-105">
            <h3 class="text-2xl font-semibold mb-2">Manage Stock</h3>
            <p>View and update inventory.</p>
        </a>
        <?php if (is_admin()): ?>
            <a href="index.php?page=expenses" class="block p-6 bg-red-500 text-white rounded-lg shadow-md hover:bg-red-600 transition duration-300 transform hover:scale-105">
                <h3 class="text-2xl font-semibold mb-2">Manage Expenses</h3>
                <p>Add and track company expenses.</p>
            </a>
            <a href="index.php?page=profit_loss" class="block p-6 bg-purple-500 text-white rounded-lg shadow-md hover:bg-purple-600 transition duration-300 transform hover:scale-105">
                <h3 class="text-2xl font-semibold mb-2">View Profit/Loss</h3>
                <p>Analyze financial performance.</p>
            </a>
            <a href="index.php?page=admin_dashboard" class="block p-6 bg-gray-700 text-white rounded-lg shadow-md hover:bg-gray-800 transition duration-300 transform hover:scale-105">
                <h3 class="text-2xl font-semibold mb-2">Admin Panel</h3>
                <p>Access administration features.</p>
            </a>
        <?php endif; ?>
    </div>
</div>

<?php include_template('footer'); ?>
