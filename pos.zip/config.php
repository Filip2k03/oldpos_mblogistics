<?php
// config.php
// Handles database configuration and connection using mysqli

$hostname = 'localhost';
$username = 'root'; // Your database username
$password = '';     // Your database password
$database = 'mbposv2'; // Your database name

// Establish the database connection
$connection = mysqli_connect($hostname, $username, $password, $database);

// Check connection
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
} else {
    // echo "Connected successfully"; // Uncomment for debugging
}

// Application Configuration
define('APP_NAME', 'MBLOGISTICS POS V2');

// Voucher Code Configuration
define('VOUCHER_CODE_LENGTH', 7); // e.g., 0000001
?>