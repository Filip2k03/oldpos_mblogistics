<?php
// login.php

// No include_template('header') here. It's handled in index.php
// The header.php will be included by the template system IF no redirect happens.

// Access the global $connection variable
global $connection;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($username) || empty($password)) {
        flash_message('error', 'Please enter both username and password.');
        redirect('index.php?page=login'); // Redirect immediately
    }

    // Use prepared statements for security
    $stmt = mysqli_prepare($connection, "SELECT id, username, password, user_type FROM users WHERE username = ?");
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 's', $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $user = mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);

        if ($user && password_verify($password, $user['password'])) {
            // Password is correct, set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['user_type'] = $user['user_type'];

            flash_message('success', 'Logged in successfully!');
            // Redirect based on user type -- THIS IS WHERE THE REDIRECT MUST HAPPEN
            if ($user['user_type'] === 'ADMIN') {
                redirect('index.php?page=admin_dashboard');
            } else {
                redirect('index.php?page=dashboard');
            }
            // NO CODE SHOULD BE EXECUTED AFTER A REDIRECT
        } else {
            flash_message('error', 'Invalid username or password.');
            redirect('index.php?page=login'); // Redirect immediately
        }
    } else {
        flash_message('error', 'Database query error: ' . mysqli_error($connection));
        redirect('index.php?page=login'); // Redirect immediately
    }
}

// If no POST request or if login failed and redirected,
// the script will continue to render the login form.
// Only include the header and footer if no redirect has occurred.
include_template('header', ['page' => 'login']);
?>

<div class="flex items-center justify-center min-h-screen -mt-20">
    <div class="bg-white p-8 rounded-lg shadow-xl w-full max-w-md">
        <h2 class="text-3xl font-bold text-gray-800 mb-6 text-center">Login</h2>
        <form action="index.php?page=login" method="POST">
            <div class="mb-4">
                <label for="username" class="block text-gray-700 text-sm font-semibold mb-2">Username:</label>
                <input type="text" id="username" name="username" class="form-input" placeholder="Enter your username" required>
            </div>
            <div class="mb-6">
                <label for="password" class="block text-gray-700 text-sm font-semibold mb-2">Password:</label>
                <input type="password" id="password" name="password" class="form-input" placeholder="Enter your password" required>
            </div>
            <div class="flex items-center justify-between">
                <button type="submit" class="btn w-full bg-burgundy hover:bg-burgundy-dark transition-colors duration-300">Login</button>
            </div>
            <p class="mt-4 text-center text-gray-600 text-sm">
                Don't have an account? <a href="index.php?page=register" class="text-burgundy hover:text-burgundy-dark font-semibold transition-colors duration-300">Register here</a>
            </p>
        </form>
    </div>
</div>

<?php include_template('footer'); ?>