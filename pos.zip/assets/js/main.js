// assets/js/main.js

document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const mobileMenu = document.getElementById('mobile-menu');
    if (mobileMenuButton && mobileMenu) {
        mobileMenuButton.addEventListener('click', function() {
            mobileMenu.classList.toggle('hidden');
        });
    }

    // --- Register Page Logic ---
    function toggleRegionField() {
        const userTypeSelect = document.getElementById('user_type');
        const regionField = document.getElementById('region-field');
        const regionSelect = document.getElementById('region_id');

        if (!userTypeSelect || !regionField || !regionSelect) {
            return; // Exit if elements not found (e.g., not on register page)
        }

        const userType = userTypeSelect.value;

        // Reset region selection and enable by default
        regionSelect.value = "";
        regionSelect.disabled = false;

        if (userType === 'Myanmar') {
            regionField.classList.remove('hidden');
            // Find and select Myanmar region programmatically
            for (let i = 0; i < regionSelect.options.length; i++) {
                if (regionSelect.options[i].text.toLowerCase() === 'myanmar') {
                    regionSelect.value = regionSelect.options[i].value;
                    regionSelect.disabled = true; // Disable selection for Myanmar users
                    break;
                }
            }
        } else if (userType === 'Malay') {
            regionField.classList.remove('hidden');
            // Find and select Malaysia region for Malay user type
            for (let i = 0; i < regionSelect.options.length; i++) {
                if (regionSelect.options[i].text.toLowerCase() === 'malaysia') {
                    regionSelect.value = regionSelect.options[i].value;
                    regionSelect.disabled = true; // Disable selection for Malay users
                    break;
                }
            }
        } else {
            regionField.classList.add('hidden');
            regionSelect.disabled = false; // Ensure it's not disabled if user type changes
        }
    }

    // Call on page load if the elements exist (for register.php)
    if (document.getElementById('user_type')) {
        document.getElementById('user_type').addEventListener('change', toggleRegionField);
        toggleRegionField(); // Call initially to set correct state
    }


    // --- Voucher Create Page Logic ---
    const voucherRegionSelect = document.getElementById('voucher_region_id');
    const pricePerKgInput = document.getElementById('price_per_kg_at_voucher');
    const weightKgInput = document.getElementById('weight_kg');
    const deliveryChargeInput = document.getElementById('delivery_charge');
    const totalAmountDisplay = document.getElementById('total_amount_display');
    const totalAmountInput = document.getElementById('total_amount_input');
    const itemBreakdownsContainer = document.getElementById('item_breakdowns_container');
    const addItemBtn = document.getElementById('add_item_btn');

    // Only run voucher specific JS if elements exist (i.e., on voucher_create.php)
    if (voucherRegionSelect && pricePerKgInput && weightKgInput) {

        // Function to update price_per_kg_at_voucher based on selected region
        window.updatePricePerKg = function() { // Made global for onchange attribute
            const selectedOption = voucherRegionSelect.options[voucherRegionSelect.selectedIndex];
            const defaultPrice = selectedOption.dataset.price;
            if (defaultPrice) {
                pricePerKgInput.value = parseFloat(defaultPrice).toFixed(2);
            } else {
                pricePerKgInput.value = '0.00';
            }
            calculateTotal(); // Recalculate total if price per kg changes
        }

        // Function to calculate and update total amount
        window.calculateTotal = function() { // Made global for oninput attributes
            const weight = parseFloat(weightKgInput.value) || 0;
            const pricePerKg = parseFloat(pricePerKgInput.value) || 0;
            const deliveryCharge = parseFloat(deliveryChargeInput.value) || 0;

            const calculatedTotal = (weight * pricePerKg) + deliveryCharge;
            totalAmountDisplay.textContent = calculatedTotal.toFixed(2);
            totalAmountInput.value = calculatedTotal.toFixed(2);
        }

        // Function to add a new item breakdown row
        function addItemBreakdownRow() {
            const newRow = document.createElement('div');
            newRow.classList.add('item-breakdown-row', 'grid', 'grid-cols-1', 'md:grid-cols-4', 'gap-4', 'items-end', 'mb-4', 'p-4', 'border', 'border-gray-200', 'rounded-md', 'bg-white', 'shadow-sm');
            newRow.innerHTML = `
                <div class="col-span-1">
                    <label class="block text-gray-700 text-sm font-semibold mb-2">Item Type:</label>
                    <input type="text" name="item_type[]" class="form-input" placeholder="e.g., Clothes, Document">
                </div>
                <div class="col-span-1">
                    <label class="block text-gray-700 text-sm font-semibold mb-2">Item Kg (optional):</label>
                    <input type="number" name="item_kg[]" class="form-input" step="0.01" min="0" placeholder="e.g., 2.5">
                </div>
                <div class="col-span-1">
                    <label class="block text-gray-700 text-sm font-semibold mb-2">Price per Kg (optional):</label>
                    <input type="number" name="item_price_per_kg[]" class="form-input" step="0.01" min="0" placeholder="e.g., 10.00">
                </div>
                <div class="col-span-1">
                    <label class="block text-gray-700 text-sm font-semibold mb-2">Item Details (JSON):</label>
                    <textarea name="item_breakdown_json[]" rows="1" class="form-input" placeholder='{"description": "5 T-shirts"}'></textarea>
                </div>
                <div class="col-span-4 text-right">
                    <button type="button" class="btn-red px-3 py-1 text-xs remove-item-btn">Remove</button>
                </div>
            `;
            itemBreakdownsContainer.appendChild(newRow);
            attachRemoveEventListeners(); // Re-attach listeners for new buttons
        }

        // Function to attach event listeners to remove buttons
        function attachRemoveEventListeners() {
            document.querySelectorAll('.remove-item-btn').forEach(button => {
                button.onclick = function() {
                    if (itemBreakdownsContainer.children.length > 1) { // Ensure at least one row remains
                        this.closest('.item-breakdown-row').remove();
                    } else {
                        showCustomAlert('At least one item breakdown is required.');
                    }
                };
            });
        }

        // Custom alert function (replaces window.alert)
        function showCustomAlert(message) {
            const alertContainer = document.createElement('div');
            alertContainer.className = 'fixed inset-x-0 top-0 flex items-center justify-center z-50 p-4 pointer-events-none';
            alertContainer.innerHTML = `
                <div class="bg-red-500 text-white px-6 py-3 rounded-md shadow-lg flex items-center space-x-2 transform transition-all duration-300 ease-out translate-y-[-50px] opacity-0" style="pointer-events: auto;">
                    <span>${message}</span>
                    <button class="ml-4 text-white hover:text-red-200 font-bold focus:outline-none" onclick="this.closest('.fixed').remove()">&times;</button>
                </div>
            `;
            document.body.appendChild(alertContainer);

            // Animate in
            setTimeout(() => {
                const innerDiv = alertContainer.querySelector('div');
                innerDiv.style.transform = 'translateY(0)';
                innerDiv.style.opacity = '1';
            }, 10); // Small delay to ensure CSS transition applies

            // Animate out and remove
            setTimeout(() => {
                const innerDiv = alertContainer.querySelector('div');
                innerDiv.style.transform = 'translateY(-50px)';
                innerDiv.style.opacity = '0';
                setTimeout(() => alertContainer.remove(), 400); // After transition
            }, 3000); // Display for 3 seconds
        }


        // Initial calls for voucher_create.php
        updatePricePerKg(); // Set initial price per kg based on default/user region
        calculateTotal();    // Calculate total on page load

        // Event Listeners for voucher_create.php
        if (addItemBtn) {
            addItemBtn.addEventListener('click', addItemBreakdownRow);
        }
        attachRemoveEventListeners(); // Attach event listeners to initial remove buttons

        // Handle disabling voucher_region_id for specific user types
        // The `userType` and `userRegionId` are passed from PHP
        // These global JS variables are set in voucher_create.php
        if (typeof userType !== 'undefined' && (userType === 'Myanmar' || userType === 'Malay') && voucherRegionSelect) {
            // Find and pre-select the region based on userRegionId passed from PHP
            for (let i = 0; i < voucherRegionSelect.options.length; i++) {
                if (voucherRegionSelect.options[i].value === userRegionId) {
                    voucherRegionSelect.value = userRegionId;
                    voucherRegionSelect.disabled = true; // Disable selection
                    break;
                }
            }
        }
    }


    // --- Loader Script ---
    const shipLoader = document.getElementById('shipLoader');
    const loaderProgress = document.getElementById('loaderProgress');

    if (shipLoader && loaderProgress) {
        // Function to update loading progress bar
        function updateLoaderProgress(percent) {
            loaderProgress.style.width = percent + '%';
        }

        // Simulate loading progress
        let progress = 0;
        const interval = setInterval(function() {
            progress += Math.floor(Math.random() * 10) + 1; // Faster random increment
            if (progress >= 95) { // Stop just before 100% to allow window.load to finish
                clearInterval(interval);
            }
            updateLoaderProgress(progress);
        }, 150); // Faster interval

        // Hide loader once the entire page is loaded
        window.addEventListener('load', function() {
            updateLoaderProgress(100); // Ensure it reaches 100%
            setTimeout(function() {
                shipLoader.classList.add('hidden'); // Fade out and hide
            }, 700); // Wait for the progress bar animation, then start fading out
        });
    }
});