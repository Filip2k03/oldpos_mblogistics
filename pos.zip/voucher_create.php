<?php
// voucher_create.php

// Access the global $connection variable
global $connection;

if (!is_logged_in()) {
    flash_message('error', 'Please log in to create a voucher.');
    redirect('index.php?page=login');
}

$user_id = $_SESSION['user_id'];
$user_type = $_SESSION['user_type'];

// --- Handle POST request (Form Submission) ---
// This entire block must be BEFORE any HTML output, including `include_template('header', ...)`
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // --- Collect and Sanitize Input ---
    $sender_name = trim($_POST['sender_name'] ?? '');
    $sender_phone = trim($_POST['sender_phone'] ?? '');
    $sender_address = trim($_POST['sender_address'] ?? '');
    $use_sender_address_for_checkout = isset($_POST['use_sender_address_for_checkout']) ? 1 : 0;

    $receiver_name = trim($_POST['receiver_name'] ?? '');
    $receiver_phone = trim($_POST['receiver_phone'] ?? '');
    $receiver_address = trim($_POST['receiver_address'] ?? ''); // Required

    $payment_method = trim($_POST['payment_method'] ?? '');
    $weight_kg = floatval($_POST['weight_kg'] ?? 0);
    $price_per_kg_at_voucher = floatval($_POST['price_per_kg_at_voucher'] ?? 0);
    $delivery_charge = floatval($_POST['delivery_charge'] ?? 0);
    $currency = trim($_POST['currency'] ?? 'USD');
    $delivery_type = trim($_POST['delivery_type'] ?? '');
    $notes = trim($_POST['notes'] ?? '');
    $voucher_region_id = intval($_POST['voucher_region_id'] ?? 0); // Voucher's origin region

    // Item breakdown details (arrays from dynamic form fields)
    $item_types = $_POST['item_type'] ?? [];
    $item_kgs = $_POST['item_kg'] ?? [];
    $item_price_per_kgs = $_POST['item_price_per_kg'] ?? [];
    $item_breakdown_jsons = $_POST['item_breakdown_json'] ?? [];

    // --- Input Validation ---
    $errors = [];
    if (empty($sender_name)) $errors[] = 'Sender Name is required.';
    if (empty($sender_phone)) $errors[] = 'Sender Phone is required.';
    if (empty($receiver_name)) $errors[] = 'Receiver Name is required.';
    if (empty($receiver_phone)) $errors[] = 'Receiver Phone is required.';
    if (empty($receiver_address)) $errors[] = 'Receiver Address is required.';
    if ($weight_kg <= 0) $errors[] = 'Weight (kg) must be greater than 0.';
    if ($price_per_kg_at_voucher <= 0) $errors[] = 'Price per kg must be greater than 0.';
    if (empty($voucher_region_id)) $errors[] = 'Voucher Origin Region is required.';

    if (!empty($errors)) {
        flash_message('error', implode('<br>', $errors));
        redirect('index.php?page=voucher_create'); // Redirect immediately with error
    }

    // Start transaction
    mysqli_begin_transaction($connection);

    try {
        // 1. Fetch region details for voucher code generation
        // Use SELECT ... FOR UPDATE for row-level locking
        $stmt_region = mysqli_prepare($connection, "SELECT prefix, current_sequence FROM regions WHERE id = ? FOR UPDATE");
        if (!$stmt_region) {
            throw new Exception("Failed to prepare region statement: " . mysqli_error($connection));
        }
        mysqli_stmt_bind_param($stmt_region, 'i', $voucher_region_id);
        mysqli_stmt_execute($stmt_region);
        $result_region = mysqli_stmt_get_result($stmt_region);
        $region_data = mysqli_fetch_assoc($result_region);
        mysqli_free_result($result_region);
        mysqli_stmt_close($stmt_region);

        if (!$region_data) {
            throw new Exception("Selected voucher region not found.");
        }

        $new_sequence = $region_data['current_sequence'] + 1;
        $voucher_code = generate_voucher_code($region_data['prefix'], $new_sequence);

        // Calculate total amount
        $total_amount = ($weight_kg * $price_per_kg_at_voucher) + $delivery_charge;

        // 2. Insert into `vouchers` table
        $stmt_voucher = mysqli_prepare($connection,
            "INSERT INTO vouchers (voucher_code, sender_name, sender_phone, sender_address, use_sender_address_for_checkout,
                                receiver_name, receiver_phone, receiver_address, payment_method, weight_kg,
                                price_per_kg_at_voucher, delivery_charge, total_amount, currency, delivery_type, notes,
                                region_id, created_by_user_id)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );
        if (!$stmt_voucher) {
            throw new Exception("Failed to prepare voucher insert statement: " . mysqli_error($connection));
        }

        mysqli_stmt_bind_param($stmt_voucher, 'ssssisssssddssdssi',
            $voucher_code, $sender_name, $sender_phone, $sender_address, $use_sender_address_for_checkout,
            $receiver_name, $receiver_phone, $receiver_address, $payment_method, $weight_kg,
            $price_per_kg_at_voucher, $delivery_charge, $total_amount, $currency, $delivery_type, $notes,
            $voucher_region_id, $user_id
        );

        if (!mysqli_stmt_execute($stmt_voucher)) {
            throw new Exception("Failed to insert voucher: " . mysqli_stmt_error($stmt_voucher));
        }
        $voucher_id = mysqli_insert_id($connection);
        mysqli_stmt_close($stmt_voucher);

        // 3. Insert into `voucher_breakdowns` table (loop through submitted items)
        if (!empty($item_types)) {
            $stmt_breakdown = mysqli_prepare($connection,
                "INSERT INTO voucher_breakdowns (voucher_id, item_type, kg, price_per_kg, item_breakdown_json)
                 VALUES (?, ?, ?, ?, ?)"
            );
            if (!$stmt_breakdown) {
                throw new Exception("Failed to prepare breakdown insert statement: " . mysqli_error($connection));
            }

            foreach ($item_types as $key => $type) {
                // Only insert if item type is provided and not empty
                if (!empty(trim($type))) {
                    $item_kg = !empty($item_kgs[$key]) ? floatval($item_kgs[$key]) : null;
                    $item_price_per_kg = !empty($item_price_per_kgs[$key]) ? floatval($item_price_per_kgs[$key]) : null;

                    // Ensure item_breakdown_json is valid JSON or null
                    $json_data = null;
                    $raw_json_input = trim($item_breakdown_jsons[$key] ?? '');
                    if (!empty($raw_json_input) && $raw_json_input !== 'null') {
                        $decoded_json = json_decode($raw_json_input);
                        if (json_last_error() === JSON_ERROR_NONE) {
                            $json_data = $raw_json_input;
                        } else {
                            flash_message('warning', "Invalid JSON for item breakdown " . ($key + 1) . ". Skipping JSON for this item.");
                        }
                    }

                    // For mysqli_stmt_bind_param, you cannot directly bind `null` for numeric types.
                    // You must pass the variable by reference, and it holds `null`.
                    // MySQL will insert NULL if the column is nullable.
                    mysqli_stmt_bind_param($stmt_breakdown, 'isdds',
                        $voucher_id, $type, $item_kg, $item_price_per_kg, $json_data
                    );
                    if (!mysqli_stmt_execute($stmt_breakdown)) {
                        throw new Exception("Failed to insert voucher breakdown: " . mysqli_stmt_error($stmt_breakdown));
                    }
                }
            }
            mysqli_stmt_close($stmt_breakdown);
        }

        // 4. Update `current_sequence` in `regions` table
        $stmt_update_sequence = mysqli_prepare($connection, "UPDATE regions SET current_sequence = ? WHERE id = ?");
        if (!$stmt_update_sequence) {
            throw new Exception("Failed to prepare sequence update statement: " . mysqli_error($connection));
        }
        mysqli_stmt_bind_param($stmt_update_sequence, 'ii', $new_sequence, $voucher_region_id);
        if (!mysqli_stmt_execute($stmt_update_sequence)) {
            throw new Exception("Failed to update region sequence: " . mysqli_stmt_error($stmt_update_sequence));
        }
        mysqli_stmt_close($stmt_update_sequence);

        mysqli_commit($connection); // Commit transaction
        flash_message('success', "Voucher '{$voucher_code}' created successfully!");
        redirect('index.php?page=voucher_view&id=' . $voucher_id); // Redirect immediately

    } catch (Exception $e) {
        mysqli_rollback($connection); // Rollback on error
        flash_message('error', 'Failed to create voucher: ' . $e->getMessage());
        redirect('index.php?page=voucher_create'); // Redirect immediately with error
    }
    // No more code here after the redirects in the try/catch block
    // The script should exit at this point if a redirect occurred.
}

// --- End of POST handling. If we reach here, it's a GET request or a POST that didn't redirect. ---

// Fetch regions for dropdown (only if not redirected by POST logic above)
$regions = [];
$stmt_regions = mysqli_query($connection, "SELECT id, region_name, prefix, price_per_kg FROM regions ORDER BY region_name");
if ($stmt_regions) {
    while ($row = mysqli_fetch_assoc($stmt_regions)) {
        $regions[] = $row;
    }
    mysqli_free_result($stmt_regions);
} else {
    flash_message('error', 'Error loading regions: ' . mysqli_error($connection));
}

// Get user's default region if applicable (for Myanmar/Malay user types)
$user_region_id = null;
if ($user_type === 'Myanmar' || $user_type === 'Malay') {
    $stmt_user_region = mysqli_prepare($connection, "SELECT region_id FROM users WHERE id = ?");
    if ($stmt_user_region) {
        mysqli_stmt_bind_param($stmt_user_region, 'i', $user_id);
        mysqli_stmt_execute($stmt_user_region);
        mysqli_stmt_bind_result($stmt_user_region, $region_id_result);
        mysqli_stmt_fetch($stmt_user_region);
        $user_region_id = $region_id_result;
        mysqli_stmt_close($stmt_user_region);
    } else {
        flash_message('error', 'Error fetching user region: ' . mysqli_error($connection));
    }
}

// Now include the header and render the form
include_template('header', ['page' => 'voucher_create']);
?>

<div class="bg-white p-8 rounded-lg shadow-xl w-full">
    <h2 class="text-3xl font-bold text-gray-800 mb-6 text-center">Create New Voucher</h2>
    <form action="index.php?page=voucher_create" method="POST">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <!-- Sender Details -->
            <div class="bg-gray-50 p-6 rounded-lg shadow-inner">
                <h3 class="text-xl font-semibold text-gray-700 mb-4 border-b pb-2">Sender Details</h3>
                <div class="mb-4">
                    <label for="sender_name" class="block text-gray-700 text-sm font-semibold mb-2">Sender Name:</label>
                    <input type="text" id="sender_name" name="sender_name" class="form-input" required>
                </div>
                <div class="mb-4">
                    <label for="sender_phone" class="block text-gray-700 text-sm font-semibold mb-2">Sender Phone:</label>
                    <input type="text" id="sender_phone" name="sender_phone" class="form-input" required>
                </div>
                <div class="mb-4">
                    <label for="sender_address" class="block text-gray-700 text-sm font-semibold mb-2">Sender Address:</label>
                    <textarea id="sender_address" name="sender_address" rows="3" class="form-input"></textarea>
                </div>
                <div class="flex items-center mb-4">
                    <input type="checkbox" id="use_sender_address_for_checkout" name="use_sender_address_for_checkout" class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                    <label for="use_sender_address_for_checkout" class="ml-2 block text-sm text-gray-900">
                        Use sender address for checkout
                    </label>
                </div>
            </div>

            <!-- Receiver Details -->
            <div class="bg-gray-50 p-6 rounded-lg shadow-inner">
                <h3 class="text-xl font-semibold text-gray-700 mb-4 border-b pb-2">Receiver Details</h3>
                <div class="mb-4">
                    <label for="receiver_name" class="block text-gray-700 text-sm font-semibold mb-2">Receiver Name:</label>
                    <input type="text" id="receiver_name" name="receiver_name" class="form-input" required>
                </div>
                <div class="mb-4">
                    <label for="receiver_phone" class="block text-gray-700 text-sm font-semibold mb-2">Receiver Phone:</label>
                    <input type="text" id="receiver_phone" name="receiver_phone" class="form-input" required>
                </div>
                <div class="mb-4">
                    <label for="receiver_address" class="block text-gray-700 text-sm font-semibold mb-2">Receiver Address:</label>
                    <textarea id="receiver_address" name="receiver_address" rows="3" class="form-input" required></textarea>
                </div>
            </div>
        </div>

        <!-- Voucher Details -->
        <div class="bg-gray-50 p-6 rounded-lg shadow-inner mb-8">
            <h3 class="text-xl font-semibold text-gray-700 mb-4 border-b pb-2">Voucher Details</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="mb-4">
                    <label for="voucher_region_id" class="block text-gray-700 text-sm font-semibold mb-2">Voucher Origin Region:</label>
                    <select id="voucher_region_id" name="voucher_region_id" class="form-select" required onchange="updatePricePerKg()">
                        <option value="">Select Region</option>
                        <?php foreach ($regions as $region): ?>
                            <option value="<?php echo htmlspecialchars($region['id']); ?>" data-price="<?php echo htmlspecialchars($region['price_per_kg']); ?>"
                                <?php echo ($user_region_id == $region['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($region['region_name']); ?> (<?php echo htmlspecialchars($region['prefix']); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-4">
                    <label for="price_per_kg_at_voucher" class="block text-gray-700 text-sm font-semibold mb-2">Price per Kg (at voucher creation):</label>
                    <input type="number" id="price_per_kg_at_voucher" name="price_per_kg_at_voucher" class="form-input" step="0.01" min="0.01" required>
                </div>
                <div class="mb-4">
                    <label for="weight_kg" class="block text-gray-700 text-sm font-semibold mb-2">Weight (kg):</label>
                    <input type="number" id="weight_kg" name="weight_kg" class="form-input" step="0.01" min="0.01" required oninput="calculateTotal()">
                </div>
                <div class="mb-4">
                    <label for="delivery_charge" class="block text-gray-700 text-sm font-semibold mb-2">Delivery Charge:</label>
                    <input type="number" id="delivery_charge" name="delivery_charge" class="form-input" step="0.01" value="0.00" oninput="calculateTotal()">
                </div>
                <div class="mb-4">
                    <label for="payment_method" class="block text-gray-700 text-sm font-semibold mb-2">Payment Method:</label>
                    <input type="text" id="payment_method" name="payment_method" class="form-input" placeholder="e.g., Cash, Bank Transfer">
                </div>
                <div class="mb-4">
                    <label for="currency" class="block text-gray-700 text-sm font-semibold mb-2">Currency:</label>
                    <input type="text" id="currency" name="currency" class="form-input" value="USD" placeholder="e.g., USD, MYR, MMK">
                </div>
                <div class="mb-4">
                    <label for="delivery_type" class="block text-gray-700 text-sm font-semibold mb-2">Delivery Type:</label>
                    <input type="text" id="delivery_type" name="delivery_type" class="form-input" placeholder="e.g., Standard, Express">
                </div>
            </div>
            <div class="mb-4">
                <label for="notes" class="block text-gray-700 text-sm font-semibold mb-2">Notes:</label>
                <textarea id="notes" name="notes" rows="3" class="form-input"></textarea>
            </div>
            <div class="text-right mt-4">
                <p class="text-lg font-bold text-gray-800">Total Amount: <span id="total_amount_display" class="text-indigo-600">0.00</span></p>
                <input type="hidden" id="total_amount_input" name="total_amount">
            </div>
        </div>

        <!-- Voucher Breakdown -->
        <div class="bg-gray-50 p-6 rounded-lg shadow-inner mb-8">
            <h3 class="text-xl font-semibold text-gray-700 mb-4 border-b pb-2">Voucher Breakdown (Items)</h3>
            <div id="item_breakdowns_container">
                <!-- Item breakdown rows will be added here by JavaScript -->
                <div class="item-breakdown-row grid grid-cols-1 md:grid-cols-4 gap-4 items-end mb-4 p-4 border border-gray-200 rounded-md bg-white shadow-sm">
                    <div class="col-span-1">
                        <label class="block text-gray-700 text-sm font-semibold mb-2">Item Type:</label>
                        <input type="text" name="item_type[]" class="form-input" placeholder="e.g., Clothes, Document">
                    </div>
                    <div class="col-span-1">
                        <label class="block text-gray-700 text-sm font-semibold mb-2">Item Kg (optional):</label>
                        <input type="number" name="item_kg[]" class="form-input" step="0.01" min="0" placeholder="e.g., 2.5">
                    </div>
                    <div class="col-span-1">
                        <label class="block text-gray-700 text-sm font-semibold mb-2">Price per Kg (optional):</label>
                        <input type="number" name="item_price_per_kg[]" class="form-input" step="0.01" min="0" placeholder="e.g., 10.00">
                    </div>
                    <div class="col-span-1">
                        <label class="block text-gray-700 text-sm font-semibold mb-2">Item Details (JSON):</label>
                        <textarea name="item_breakdown_json[]" rows="1" class="form-input" placeholder='{"description": "5 T-shirts"}'></textarea>
                    </div>
                    <div class="col-span-4 text-right">
                        <button type="button" class="btn-red px-3 py-1 text-xs remove-item-btn">Remove</button>
                    </div>
                </div>
            </div>
            <button type="button" id="add_item_btn" class="btn btn-blue mt-4">Add Another Item</button>
        </div>

        <div class="flex justify-center">
            <button type="submit" class="btn bg-burgundy hover:bg-burgundy-dark px-8 py-3 text-lg">Generate Voucher</button>
        </div>
    </form>
</div>

<script>
    // These PHP variables are needed by assets/js/main.js
    const userType = "<?php echo htmlspecialchars($user_type); ?>";
    const userRegionId = "<?php echo htmlspecialchars($user_region_id); ?>";
</script>

<?php include_template('footer'); ?>