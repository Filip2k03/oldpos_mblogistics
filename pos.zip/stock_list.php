<?php
// stock_list.php
// Placeholder for Stock List page

include_template('header', ['page' => 'stock_list']);

if (!is_logged_in()) {
    flash_message('error', 'Please log in to view stock.');
    redirect('index.php?page=login');
}
?>

<div class="bg-white p-8 rounded-lg shadow-xl text-center">
    <h2 class="text-3xl font-bold text-gray-800 mb-6">Stock List</h2>
    <p class="text-gray-600 mb-4">This is a placeholder for the Stock List page.</p>
    <p class="text-gray-600">Here, you would typically display an inventory of items, manage stock levels, etc.</p>

    <div class="mt-8">
        <a href="index.php?page=dashboard" class="btn btn-blue px-6 py-2">Back to Dashboard</a>
    </div>
</div>

<?php include_template('footer'); ?>