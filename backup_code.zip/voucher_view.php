<?php
// voucher_view.php - Displays details of a specific voucher and allows status/notes update.

// --- Include Configuration and Database Connection ---
// Ensure config.php is loaded FIRST to define constants and establish $connection
require_once 'config.php';

// --- Dummy Functions (These should ideally be in a shared 'helpers.php' or 'functions.php') ---
// If you have a separate functions file, remove these dummy definitions
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Set a default timezone to ensure consistent date/time logging
date_default_timezone_set('Asia/Yangon'); // IMPORTANT: Set to your server's/application's timezone

// Dummy is_logged_in function
if (!function_exists('is_logged_in')) {
    function is_logged_in() {
        return isset($_SESSION['user_id']);
    }
}

// Dummy flash_message function
if (!function_exists('flash_message')) {
    function flash_message($type, $message) {
        $_SESSION['flash'] = ['type' => $type, 'message' => $message];
    }
}

// Dummy redirect function
if (!function_exists('redirect')) {
    function redirect($url) {
        header("Location: " . $url);
        exit();
    }
}

// Dummy is_admin function (relies on USER_TYPE_ADMIN from config.php)
if (!function_exists('is_admin')) {
    function is_admin() {
        return isset($_SESSION['user_type']) && defined('USER_TYPE_ADMIN') && $_SESSION['user_type'] === USER_TYPE_ADMIN;
    }
}

// Dummy include_template function
if (!function_exists('include_template')) {
    function include_template($template_name, $data = []) {
        extract($data);
        if ($template_name === 'header') {
            ?>
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>View Voucher</title>
                <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
                <style>
                    .flash-message {
                        padding: 0.75rem 1.25rem;
                        margin-bottom: 1rem;
                        border: 1px solid transparent;
                        border-radius: 0.25rem;
                        opacity: 1;
                        transition: opacity 0.5s ease-out;
                    }
                    .flash-message.hidden {
                        opacity: 0;
                        display: none;
                    }
                </style>
            </head>
            <body class="bg-gray-100 p-6">
            <div class="container mx-auto">
            <?php
            if (isset($_SESSION['flash'])) {
                $flash = $_SESSION['flash'];
                $class = '';
                switch ($flash['type']) {
                    case 'success': $class = 'bg-green-100 text-green-700 border-green-400'; break;
                    case 'error': $class = 'bg-red-100 text-red-700 border-red-400'; break;
                    case 'info': $class = 'bg-blue-100 text-blue-700 border-blue-400'; break;
                    case 'warning': $class = 'bg-yellow-100 text-yellow-700 border-yellow-400'; break;
                }
                echo "<div class='flash-message p-4 mb-4 text-sm rounded-lg border {$class}' role='alert'>{$flash['message']}</div>";
                unset($_SESSION['flash']);
                ?>
                <script>
                    setTimeout(() => {
                        const flash = document.querySelector('.flash-message');
                        if (flash) {
                            flash.classList.add('hidden');
                        }
                    }, 5000);
                </script>
                <?php
            }
        } elseif ($template_name === 'footer') {
            echo '</div></body></html>';
        }
    }
}
// --- END Dummy Functions ---


// --- Authentication Check ---
if (!is_logged_in()) {
    flash_message('error', 'Please log in to view vouchers.');
    redirect('index.php?page=login');
}

// --- Get Voucher ID ---
$voucher_id = intval($_GET['id'] ?? 0);
if ($voucher_id <= 0) {
    flash_message('error', 'Invalid voucher ID provided.');
    redirect('index.php?page=voucher_list');
}

global $connection;
$user_id = $_SESSION['user_id'];
$user_type = $_SESSION['user_type'] ?? null; // Get user_type from session (should be set during login)
$is_admin = is_admin();

// --- Fetch Current User's Details (for permissions and logging) ---
$user_region_id = null;
$current_username = 'System'; // Default username
$stmt_user = mysqli_prepare($connection, "SELECT username, region_id FROM users WHERE id = ?");
if ($stmt_user) {
    mysqli_stmt_bind_param($stmt_user, 'i', $user_id);
    mysqli_stmt_execute($stmt_user);
    $result_user = mysqli_stmt_get_result($stmt_user);
    if ($row = mysqli_fetch_assoc($result_user)) {
        $user_region_id = $row['region_id'];
        $current_username = $row['username'];
    }
    mysqli_stmt_close($stmt_user);
}

$possible_statuses = ['Pending', 'In Transit', 'Delivered', 'Received', 'Cancelled', 'Returned'];

// --- Handle POST request (Form Submission for Status and Notes Update) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_status = trim($_POST['status'] ?? '');
    $new_note_entry = trim($_POST['notes'] ?? ''); // This is the NEW note to be added

    $errors = [];
    if (!in_array($new_status, $possible_statuses)) {
        $errors[] = 'Invalid status selected.';
    }

    // Fetch current voucher data to verify permission AND get existing notes
    // We need origin_region_id and destination_region_id for permission checks
    $stmt_auth_check = mysqli_prepare($connection, "SELECT created_by_user_id, status, region_id, destination_region_id, notes FROM vouchers WHERE id = ?");
    if ($stmt_auth_check) {
        mysqli_stmt_bind_param($stmt_auth_check, 'i', $voucher_id);
        mysqli_stmt_execute($stmt_auth_check);
        $result_auth_check = mysqli_stmt_get_result($stmt_auth_check);
        $voucher_current_data = mysqli_fetch_assoc($result_auth_check);
        mysqli_stmt_close($stmt_auth_check);

        if (!$voucher_current_data) {
            $errors[] = 'Voucher not found for permission check.';
        } else {
            // --- Permission Check for UPDATE ---
            $can_update = false; // Default to no permission

            if ($is_admin || ($voucher_current_data['created_by_user_id'] == $user_id)) {
                $can_update = true; // Admin or creator can always update
            } elseif (($user_type === USER_TYPE_MYANMAR || $user_type === USER_TYPE_MALAY) && $user_region_id !== null) {
                // Myanmar/Malay users can update based on status and region
                if ($voucher_current_data['status'] === 'Pending' && $user_region_id == $voucher_current_data['region_id']) {
                    // Pending: Only origin region user can update
                    $can_update = true;
                } elseif ($voucher_current_data['status'] === 'Delivered') {
                    // Delivered: Any Myanmar/Malay user can update (if this is desired, otherwise restrict further)
                    // If "all user can see" implies "all user can update", then true.
                    // If only destination region can update delivered, add: && $user_region_id == $voucher_current_data['destination_region_id']
                    $can_update = true;
                } elseif ($user_region_id == $voucher_current_data['region_id'] || $user_region_id == $voucher_current_data['destination_region_id']) {
                    // For other statuses (In Transit, Cancelled, Returned), if their region is involved
                    $can_update = true;
                }
            }

            if (!$can_update) {
                $errors[] = 'You do not have permission to update this voucher.';
            }
        }
    } else {
        $errors[] = 'Database error during permission check: ' . mysqli_error($connection);
    }

    if (!empty($errors)) {
        flash_message('error', implode('<br>', $errors));
    } else {
        // ** FIXED LOGIC: APPEND NOTE INSTEAD OF REPLACING **
        $existing_notes = $voucher_current_data['notes'];
        $updated_notes = $existing_notes; // Start with the old notes

        // Only add a new entry if the user actually typed something
        if (!empty($new_note_entry)) {
            $timestamp = date('Y-m-d H:i:s');
            $log_entry = "--- {$timestamp} by {$current_username} ---\n{$new_note_entry}\n";

            // Append the new log entry to the existing notes
            $updated_notes = $existing_notes . (empty($existing_notes) ? '' : "\n") . $log_entry;
        }

        // Prepare and execute the update
        $update_sql = "UPDATE vouchers SET status = ?, notes = ? WHERE id = ?";
        $stmt_update = mysqli_prepare($connection, $update_sql);

        if ($stmt_update) {
            mysqli_stmt_bind_param($stmt_update, 'ssi', $new_status, $updated_notes, $voucher_id);
            if (mysqli_stmt_execute($stmt_update)) {
                flash_message('success', 'Voucher status and notes updated successfully!');
            } else {
                flash_message('error', 'Failed to update voucher: ' . mysqli_stmt_error($stmt_update));
            }
            mysqli_stmt_close($stmt_update);
        } else {
            flash_message('error', 'Failed to prepare update statement: ' . mysqli_error($connection));
        }
    }
}

// --- Fetch Full Voucher Details for Display ---
$voucher = null;
$breakdowns = [];
$total_breakdown_kg = 0.00;

try {
    $query_voucher = "SELECT v.*, r_origin.region_name AS origin_region_name, r_origin.prefix AS origin_prefix,
                             r_dest.region_name AS destination_region_name, u.username AS created_by_username
                      FROM vouchers v
                      LEFT JOIN regions r_origin ON v.region_id = r_origin.id
                      LEFT JOIN regions r_dest ON v.destination_region_id = r_dest.id
                      LEFT JOIN users u ON v.created_by_user_id = u.id
                      WHERE v.id = ?";

    $stmt_voucher = mysqli_prepare($connection, $query_voucher);
    if (!$stmt_voucher) {
        throw new Exception("Failed to prepare voucher fetch statement: " . mysqli_error($connection));
    }

    mysqli_stmt_bind_param($stmt_voucher, 'i', $voucher_id);
    mysqli_stmt_execute($stmt_voucher);
    $result_voucher = mysqli_stmt_get_result($stmt_voucher);
    $voucher = mysqli_fetch_assoc($result_voucher);
    mysqli_stmt_close($stmt_voucher);

    if (!$voucher) {
        flash_message('error', 'Voucher not found.');
        redirect('index.php?page=voucher_list');
    }

    // --- START MODIFIED VIEW PERMISSION LOGIC ---
    $has_view_permission = false; // Default to no permission

    if ($is_admin) {
        $has_view_permission = true; // Admins can always view
    } elseif ($voucher['created_by_user_id'] == $user_id) {
        $has_view_permission = true; // Voucher creator can always view
    } elseif (($user_type === USER_TYPE_MYANMAR || $user_type === USER_TYPE_MALAY) && $user_region_id !== null) {
        // Myanmar/Malay users: specific rules based on status
        if ($voucher['status'] === 'Pending') {
            // Pending: Only viewable if user's region is the origin region
            if ($user_region_id == $voucher['region_id']) {
                $has_view_permission = true;
            }
        } elseif ($voucher['status'] === 'Delivered') {
            // Delivered: Viewable by ALL Myanmar/Malay users (as per "all user can see")
            $has_view_permission = true;
        } else {
            // For 'In Transit', 'Cancelled', 'Returned' statuses:
            // Viewable if user's region is either origin or destination
            if ($user_region_id == $voucher['region_id'] || $user_region_id == $voucher['destination_region_id']) {
                $has_view_permission = true;
            }
        }
    } else {
        // For any other logged-in user types not covered by specific rules (if any)
        // You might want to default to false, or add more specific rules here.
        // For now, if they are not admin, creator, or Myanmar/Malay, they cannot view unless explicitly allowed.
        $has_view_permission = false;
    }

    if (!$has_view_permission) {
        flash_message('error', 'You do not have permission to view this voucher.');
        redirect('index.php?page=voucher_list');
    }
    // --- END MODIFIED VIEW PERMISSION LOGIC ---


    // Fetch breakdowns
    $stmt_breakdowns = mysqli_prepare($connection, "SELECT item_type, kg, price_per_kg FROM voucher_breakdowns WHERE voucher_id = ?");
    if ($stmt_breakdowns) {
        mysqli_stmt_bind_param($stmt_breakdowns, 'i', $voucher_id);
        mysqli_stmt_execute($stmt_breakdowns);
        $result_breakdowns = mysqli_stmt_get_result($stmt_breakdowns);
        while ($row = mysqli_fetch_assoc($result_breakdowns)) {
            $breakdowns[] = $row;
            $total_breakdown_kg += (float)$row['kg'];
        }
        mysqli_stmt_close($stmt_breakdowns);
    }

    // Determine Current Region Display
    $current_region_display = 'N/A';
    switch ($voucher['status']) {
        case 'Pending': $current_region_display = htmlspecialchars($voucher['origin_region_name']); break;
        case 'In Transit': case 'Delivered': case 'Received': $current_region_display = htmlspecialchars($voucher['destination_region_name']); break;
        case 'Cancelled': case 'Returned': $current_region_display = 'N/A (Status: ' . htmlspecialchars($voucher['status']) . ')'; break;
        default: $current_region_display = 'Unknown'; break;
    }

} catch (Exception $e) {
    error_log("Voucher View Error: " . $e->getMessage());
    flash_message('error', 'An error occurred while loading the voucher.');
    redirect('index.php?page=voucher_list');
}

// --- Include Header and Render HTML ---
include_template('header', ['page' => 'voucher_view']);
?>

<div class="bg-white p-8 rounded-lg shadow-xl w-full max-w-6xl mx-auto my-8">
    <h2 class="text-3xl font-bold text-gray-800 mb-6 text-center">Voucher Details: #<?php echo htmlspecialchars($voucher['voucher_code']); ?></h2>

    <?php if ($voucher): ?>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-8">
            <!-- Voucher Main Details -->
            <div class="bg-blue-50 p-6 rounded-lg shadow-inner">
                <h3 class="text-xl font-semibold text-gray-700 mb-4 border-b pb-2">Voucher Information</h3>
                <p><strong class="text-gray-800">Voucher Code:</strong> <span class="font-mono text-indigo-600 text-lg"><?php echo htmlspecialchars($voucher['voucher_code']); ?></span></p>
                <p><strong class="text-gray-800">Origin Region:</strong> <?php echo htmlspecialchars($voucher['origin_region_name']); ?></p>
                <p><strong class="text-gray-800">Destination Region:</strong> <?php echo htmlspecialchars($voucher['destination_region_name']); ?></p>
                <p><strong class="text-gray-800">Current Region:</strong> <?php echo $current_region_display; ?></p>
                <p><strong class="text-gray-800">Total Weight:</strong> <?php echo htmlspecialchars(number_format((float)$voucher['weight_kg'], 2)); ?> kg</p>
                <p><strong class="text-gray-800">Delivery Charge:</strong> <?php echo htmlspecialchars(number_format((float)$voucher['delivery_charge'], 2)); ?></p>
                <p class="text-xl font-bold"><strong class="text-gray-800">Total Amount:</strong> <span class="text-green-600"><?php echo htmlspecialchars(number_format((float)$voucher['total_amount'], 2) . ' ' . $voucher['currency']); ?></span></p>
                <p><strong class="text-gray-800">Payment Method:</strong> <?php echo htmlspecialchars($voucher['payment_method'] ?: 'N/A'); ?></p>
                <p><strong class="text-gray-800">Delivery Type:</strong> <?php echo htmlspecialchars($voucher['delivery_type'] ?: 'N/A'); ?></p>
                <p><strong class="text-gray-800">Status:</strong>
                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                        <?php
                            switch ($voucher['status']) {
                                case 'Pending': echo 'bg-yellow-100 text-yellow-800'; break;
                                case 'In Transit': echo 'bg-blue-100 text-blue-800'; break;
                                case 'Delivered': echo 'bg-green-100 text-green-800'; break;
                                case 'Received': echo 'bg-teal-100 text-teal-800'; break;
                                case 'Cancelled': echo 'bg-red-100 text-red-800'; break;
                                case 'Returned': echo 'bg-purple-100 text-purple-800'; break;
                                default: echo 'bg-gray-100 text-gray-800'; break;
                            }
                        ?>">
                        <?php echo htmlspecialchars($voucher['status']); ?>
                    </span>
                </p>
                <p><strong class="text-gray-800">Created By:</strong> <?php echo htmlspecialchars($voucher['created_by_username']); ?></p>
                <p><strong class="text-gray-800">Created At:</strong> <?php echo date('Y-m-d H:i:s', strtotime($voucher['created_at'])); ?></p>
            </div>

            <!-- Sender & Receiver Details -->
            <div class="bg-green-50 p-6 rounded-lg shadow-inner">
                <h3 class="text-xl font-semibold text-gray-700 mb-4 border-b pb-2">Sender Information</h3>
                <p><strong class="text-gray-800">Name:</strong> <?php echo htmlspecialchars($voucher['sender_name']); ?></p>
                <p><strong class="text-gray-800">Phone:</strong> <?php echo htmlspecialchars($voucher['sender_phone']); ?></p>
                <p><strong class="text-gray-800">Address:</strong> <?php echo nl2br(htmlspecialchars($voucher['sender_address'] ?: 'N/A')); ?></p>
            </div>

            <div class="bg-yellow-50 p-6 rounded-lg shadow-inner">
                <h3 class="text-xl font-semibold text-gray-700 mb-4 border-b pb-2">Receiver Information</h3>
                <p><strong class="text-gray-800">Name:</strong> <?php echo htmlspecialchars($voucher['receiver_name']); ?></p>
                <p><strong class="text-gray-800">Phone:</strong> <?php echo htmlspecialchars($voucher['receiver_phone']); ?></p>
                <p><strong class="text-gray-800">Address:</strong> <?php echo nl2br(htmlspecialchars($voucher['receiver_address'])); ?></p>
            </div>
        </div>

        <!-- Notes and Status Update Form -->
        <div class="bg-purple-50 p-6 rounded-lg shadow-inner mb-8">
            <h3 class="text-xl font-semibold text-gray-700 mb-4 border-b pb-2">Voucher Notes & Status Update</h3>
            <div class="mb-4 bg-white p-4 rounded-lg border max-h-60 overflow-y-auto">
                <p class="text-sm text-gray-800 whitespace-pre-wrap"><?php echo htmlspecialchars($voucher['notes'] ?: 'No notes yet.'); ?></p>
            </div>

            <?php
            // Determine if current user has permission to update status/notes
            $can_update_status_notes = false; // Default to no permission

            if ($is_admin || ($voucher['created_by_user_id'] == $user_id)) {
                $can_update_status_notes = true; // Admin or creator can always update
            } elseif (($user_type === USER_TYPE_MYANMAR || $user_type === USER_TYPE_MALAY) && $user_region_id !== null) {
                // Myanmar/Malay users can update based on status and region
                if ($voucher['status'] === 'Pending' && $user_region_id == $voucher['region_id']) {
                    // Pending: Only origin region user can update
                    $can_update_status_notes = true;
                } elseif ($voucher['status'] === 'Delivered') {
                    // Delivered: Any Myanmar/Malay user can update (if this is desired, otherwise restrict further)
                    // If "all user can see" implies "all user can update", then true.
                    // If only destination region can update delivered, add: && $user_region_id == $voucher['destination_region_id']
                    $can_update_status_notes = true;
                } elseif ($user_region_id == $voucher['region_id'] || $user_region_id == $voucher['destination_region_id']) {
                    // For other statuses (In Transit, Cancelled, Returned), if their region is involved
                    $can_update_status_notes = true;
                }
            }

            if ($can_update_status_notes):
            ?>
            <form action="index.php?page=voucher_view&id=<?php echo htmlspecialchars($voucher['id']); ?>" method="POST" class="mt-4">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                        <label for="status" class="block text-gray-700 text-sm font-semibold mb-2">Change Status:</label>
                        <select id="status" name="status" class="border border-gray-300 rounded-lg p-2 w-full focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                            <?php foreach ($possible_statuses as $status_option): ?>
                                <option value="<?php echo htmlspecialchars($status_option); ?>"
                                    <?php echo ($voucher['status'] === $status_option) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($status_option); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label for="notes" class="block text-gray-700 text-sm font-semibold mb-2">Add New Note (Optional):</label>
                        <textarea id="notes" name="notes" rows="3" class="border border-gray-300 rounded-lg p-2 w-full focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Add a new note to the log..."></textarea>
                    </div>
                </div>
                <div class="flex justify-end">
                    <button type="submit" class="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded-lg shadow-md transition duration-300">Update Voucher</button>
                </div>
            </form>
            <?php else: ?>
                <p class="text-gray-600 italic">You do not have permission to update the status or notes for this voucher.</p>
            <?php endif; ?>
        </div>

        <!-- Item Breakdown -->
        <div class="bg-red-50 p-6 rounded-lg shadow-inner mb-8">
            <h3 class="text-xl font-semibold text-gray-700 mb-4 border-b pb-2">Item Breakdown</h3>
            <?php if (empty($breakdowns)): ?>
                <p class="text-gray-600">No item breakdowns for this voucher.</p>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Item Type</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kg</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price/Kg</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php
                            $breakdown_subtotal = 0;
                            foreach ($breakdowns as $item):
                                $subtotal = (float)$item['kg'] * (float)$item['price_per_kg'];
                                $breakdown_subtotal += $subtotal;
                            ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($item['item_type'] ?: 'N/A'); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo htmlspecialchars(number_format((float)$item['kg'], 2)); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo htmlspecialchars(number_format((float)$item['price_per_kg'], 2)); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?php echo htmlspecialchars(number_format($subtotal, 2)); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <p class="text-lg font-bold text-gray-800 mt-4">Total Kg (from items): <span class="text-blue-700"><?php echo htmlspecialchars(number_format($total_breakdown_kg, 2)); ?> kg</span></p>
            <?php endif; ?>
        </div>

        <!-- Action Buttons -->
        <div class="flex justify-center mt-8 space-x-4">
            <a href="voucher_print.php?id=<?php echo htmlspecialchars($voucher['id']); ?>" target="_blank" class="bg-sky-500 hover:bg-sky-600 text-white font-semibold py-2 px-4 rounded-lg shadow-md transition duration-300">Print Voucher</a>
            <a href="index.php?page=voucher_list" class="bg-slate-700 hover:bg-slate-950 text-white font-semibold py-2 px-4 rounded-lg shadow-md transition duration-300">Back to Voucher List</a>
        </div>
    <?php else: ?>
        <div class="text-center">
            <p class="text-red-500">Voucher data could not be loaded.</p>
        </div>
    <?php endif; ?>
</div>

<?php include_template('footer'); ?>